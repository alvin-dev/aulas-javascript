// JavaScript Document
alert('Meu primeiro codigo JavaScript');